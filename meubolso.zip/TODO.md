# TODO — Meu Orçamento

## 1. Registrar e classificar lançamentos
- [x] Permitir registrar, editar e excluir receitas e despesas, com valor, data, descrição e categoria.
- [x] Classificar as despesas em mensais de valor fixo, mensais de valor variável e esporádicas.

## 2. Painéis mensais e saldo
- [x] Mostrar painéis separados por mês, com navegação entre períodos e resumo de receitas, despesas e valor restante.
- [x] Quero painéis para cada mês, onde estarão as despesas mensais de valor fixo, despesas mensais de valor variável e despesas esporádicas.

## 3. Orçamentos por categoria
- [x] Permitir definir um orçamento mensal por categoria e comparar valor planejado, realizado e disponível.
- [x] Mostrar quanto sobra no mês e quanto ainda resta em cada categoria; quando o realizado passar do limite, exibir a porcentagem excedida em linguagem simples, por exemplo: “A categoria Restaurantes está 32% acima do orçamento”.

## 4. Gastos por categoria e tendências
- [x] Mostrar um painel visual de gastos por categoria, com totais e participação de cada categoria no mês.
- [x] Mostrar um gráfico de tendência mês a mês para acompanhar a evolução de receitas, despesas e saldo.

## 5. Análises em linguagem simples
- [x] Gerar análises automáticas em linguagem simples, incluindo alertas percentuais para categorias acima do orçamento.

## 6. Importação e exportação CSV
- [x] Dar suporte à importação de movimentações por arquivo CSV, com validação e pré-visualização antes da confirmação.
- [x] Dar suporte à exportação dos dados financeiros para CSV.

## 7. Privacidade e armazenamento local
- [x] “Mantenha os dados no navegador.” No app web, manter os dados nesse navegador; no dispositivo nativo, persistir localmente no aparelho, sem conta ou servidor, entre os usos.
